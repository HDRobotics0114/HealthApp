@extends('layouts.app')

@section('content')
    <div class="jumbotron text-center">
        <h1>Welcome To My Web project named HealthApp! (maybe I will rename this to DD - DoriDarmon or something) I intend to further delevop this project later!</h1>
        <p>Hopefully it will be helpful for the people</p>
        <p>Made using Laravel. And Laravel as i found out is an amazing Web programming tool!</p>
        <p><a class="btn btn-primary btn-lg" href="/login" role="button">Login</a> <a class="btn btn-success btn-lg" href="/register" role="button">Register</a></p>
    </div>
@endsection
